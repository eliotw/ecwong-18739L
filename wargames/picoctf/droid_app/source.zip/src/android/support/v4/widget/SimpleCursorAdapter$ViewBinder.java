// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.widget;

import android.database.Cursor;
import android.view.View;

// Referenced classes of package android.support.v4.widget:
//            SimpleCursorAdapter

public static interface 
{

    public abstract boolean setViewValue(View view, Cursor cursor, int i);
}
