// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.widget;

import android.content.ComponentName;
import android.content.Context;
import android.view.View;

// Referenced classes of package android.support.v4.widget:
//            SearchViewCompat

static class 
    implements 
{

    public CharSequence getQuery(View view)
    {
        return null;
    }

    public boolean isIconified(View view)
    {
        return true;
    }

    public boolean isQueryRefinementEnabled(View view)
    {
        return false;
    }

    public boolean isSubmitButtonEnabled(View view)
    {
        return false;
    }

    public Object newOnCloseListener( )
    {
        return null;
    }

    public Object newOnQueryTextListener( )
    {
        return null;
    }

    public View newSearchView(Context context)
    {
        return null;
    }

    public void setIconified(View view, boolean flag)
    {
    }

    public void setImeOptions(View view, int i)
    {
    }

    public void setInputType(View view, int i)
    {
    }

    public void setMaxWidth(View view, int i)
    {
    }

    public void setOnCloseListener(Object obj, Object obj1)
    {
    }

    public void setOnQueryTextListener(Object obj, Object obj1)
    {
    }

    public void setQuery(View view, CharSequence charsequence, boolean flag)
    {
    }

    public void setQueryHint(View view, CharSequence charsequence)
    {
    }

    public void setQueryRefinementEnabled(View view, boolean flag)
    {
    }

    public void setSearchableInfo(View view, ComponentName componentname)
    {
    }

    public void setSubmitButtonEnabled(View view, boolean flag)
    {
    }

    ()
    {
    }
}
